/**
 * Copyright 2020 Design Barn Inc.
 */

module.exports = { extends: ["@commitlint/config-conventional"] };
