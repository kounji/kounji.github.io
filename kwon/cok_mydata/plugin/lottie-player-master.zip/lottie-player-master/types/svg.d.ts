/**
 * Copyright 2022 Design Barn Inc.
 */

declare module "*.svg" {
  const content: any;
  export default content;
}
