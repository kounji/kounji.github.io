/**
 * Copyright 2022 Design Barn Inc.
 */

declare module "lottie-web/build/player/lottie";
