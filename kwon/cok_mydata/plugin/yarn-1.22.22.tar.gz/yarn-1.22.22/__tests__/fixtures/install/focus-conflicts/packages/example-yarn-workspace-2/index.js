#!/usr/bin/env node

console.log('hey');