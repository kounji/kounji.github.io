module.exports = {
  publicPath: ""
};
