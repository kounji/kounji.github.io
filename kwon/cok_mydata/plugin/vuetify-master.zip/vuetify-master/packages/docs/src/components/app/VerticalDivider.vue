<template>
  <v-divider
    class="mx-2 my-auto"
    style="height: 16px;"
    inset
    vertical
  />
</template>

<script setup>
  //
</script>
