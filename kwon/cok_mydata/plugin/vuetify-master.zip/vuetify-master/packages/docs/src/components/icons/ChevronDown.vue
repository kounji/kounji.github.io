<template>
  <v-icon
    class="hidden-sm-and-down"
    icon="mdi-chevron-down"
    size="14"
  />
</template>

<script setup>
  //
</script>
