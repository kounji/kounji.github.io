<template>
  <v-sheet
    class="overflow-hidden"
    border
    rounded
  >
    <slot />
  </v-sheet>
</template>

<script setup>
  //
</script>
