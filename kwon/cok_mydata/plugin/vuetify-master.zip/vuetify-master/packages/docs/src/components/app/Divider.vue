<template>
  <v-divider class="my-5" />
</template>

<script setup>
  //
</script>
