<template>
  <div>
    <div class="d-print-none">
      Screen Only (Hide on print only)
    </div>
    <div class="d-none d-print-block">
      Print Only (Hide on screen only)
    </div>
    <div class="d-none d-lg-block d-print-block">
      Hide up to large on screen, but always show on print
    </div>
  </div>
</template>
