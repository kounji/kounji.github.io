<template>
  <div>
    <div class="d-block pa-2 bg-deep-purple">
      d-block
    </div>
    <div class="d-block pa-2 bg-black">
      d-block
    </div>
  </div>
</template>
