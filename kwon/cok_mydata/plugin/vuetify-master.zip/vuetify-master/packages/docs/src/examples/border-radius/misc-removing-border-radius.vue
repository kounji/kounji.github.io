<template>
  <v-container class="text-center">
    <v-btn
      color="primary"
      rounded="0"
      text="Update Account"
      flat
    ></v-btn>
  </v-container>
</template>
