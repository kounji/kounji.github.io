console.log(require("b/package.json").version)
