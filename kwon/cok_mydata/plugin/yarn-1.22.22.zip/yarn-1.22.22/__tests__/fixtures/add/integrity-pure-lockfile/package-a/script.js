var fs = require('fs');

fs.writeFileSync('temp.txt', 'TEST');
