require('fs').writeFileSync('foo.txt', 'foobar');
