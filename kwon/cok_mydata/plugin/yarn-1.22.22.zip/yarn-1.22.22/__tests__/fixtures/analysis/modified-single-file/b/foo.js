foo();
bar();
