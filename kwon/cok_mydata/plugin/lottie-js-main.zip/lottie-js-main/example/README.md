# lottie-js Example

1. Run Yarn/NPM install
```
yarn install
```

2. Run example script
```
yarn example
```
