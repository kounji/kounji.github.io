import { PropertyType, ShapeType, StarType } from '../constants';
import { Property } from '../properties';
import { Shape } from './shape';

/**
 * Star shape type.
 */
export class StarShape extends Shape {
  /**
   * Shape type
   */
  public readonly type = ShapeType.STAR;

  public position: Property = new Property(this, PropertyType.POSITION);

  public innerRadius: Property = new Property(this, PropertyType.NUMBER);

  public innerRoundness: Property = new Property(this, PropertyType.NUMBER);

  public outerRadius: Property = new Property(this, PropertyType.NUMBER);

  public outerRoundness: Property = new Property(this, PropertyType.NUMBER);

  public rotation: Property = new Property(this, PropertyType.ROTATION);

  public points: Property = new Property(this, PropertyType.NUMBER);

  public starType: StarType = StarType.STAR;

  public direction?: number;

  /**
   * Convert the Lottie JSON object to class instance.
   *
   * @param json    JSON object
   * @returns       StarShape instance
   */
  public fromJSON(json: Record<string, any>): StarShape {
    // Base shape
    super.fromJSON(json);

    // This shape
    this.position.fromJSON(json.p);

    // poly star has two types. these two fields only exist on type 1. see star types in constants folder for reference
    if (json.sy === 1) {
      this.innerRadius.fromJSON(json.ir);
      this.innerRoundness.fromJSON(json.is);
    }
    this.outerRadius.fromJSON(json.or);
    this.outerRoundness.fromJSON(json.os);
    this.rotation.fromJSON(json.r);
    this.points.fromJSON(json.pt);
    this.starType = json.sy;
    this.direction = json.d;

    return this;
  }

  /**
   * Convert the class instance to Lottie JSON object.
   *
   * Called by Javascript when serializing object with JSON.stringify()
   *
   * @returns       JSON object
   */
  public toJSON(): Record<string, any> {
    const json = super.toJSON();

    return Object.assign(json, {
      // This shape
      p: this.position,
      ...(this.starType === 1 && { ir: this.innerRadius }),
      ...(this.starType === 1 && { is: this.innerRoundness }),
      or: this.outerRadius,
      os: this.outerRoundness,
      r: this.rotation,
      pt: this.points,
      sy: this.starType,
      d: this.direction,
    });
  }
}
