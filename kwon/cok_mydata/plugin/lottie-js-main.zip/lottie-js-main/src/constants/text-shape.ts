export enum TextShape {
  SQUARE = 1,
  RAMP_UP = 2,
  RAMP_DOWN = 3,
  TRIANGLE = 4,
  ROUND = 5,
  SMOOTH = 6,
}
