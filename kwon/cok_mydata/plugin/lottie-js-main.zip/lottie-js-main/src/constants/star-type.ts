export enum StarType {
  STAR = 1,
  POLYGON = 2,
}
