export enum TextBased {
  CHARACTERS = 1,
  CHARACTER_EXCLUDING_SPACES = 2,
  WORDS = 3,
  LINES = 4,
}
