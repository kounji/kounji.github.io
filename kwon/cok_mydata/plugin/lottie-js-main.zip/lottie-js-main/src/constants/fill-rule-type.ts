export enum FillRuleType {
  EVEN_ODD = 1,
  NONZERO = 2,
}
