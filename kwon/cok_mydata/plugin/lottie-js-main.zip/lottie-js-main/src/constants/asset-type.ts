export enum AssetType {
  PRECOMPOSITION = 0,
  IMAGE = 1,
}
