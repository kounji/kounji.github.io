export enum RepeaterComposite {
  ABOVE = 1,
  BELOW = 2,
}
