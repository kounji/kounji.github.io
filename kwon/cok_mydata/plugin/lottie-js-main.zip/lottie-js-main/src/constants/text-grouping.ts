export enum TextGrouping {
  CHARACTERS = 1,
  WORD,
  LINE,
  ALL,
}
