export enum EffectValueType {
  SLIDER = 0,
  ANGLE = 1,
  COLOR = 2,
  POINT = 3,
  CHECKBOX = 4,
  IGNORED = 6,
  DROPDOWN = 7,
  LAYER = 10,
}
