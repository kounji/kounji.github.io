export enum TrimMode {
  SIMULTANEOUSLY = 1,
  INDIVIDUALLY = 2,
}
