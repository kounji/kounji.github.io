export enum LineCapType {
  BUTT = 1,
  ROUND = 2,
  PROJECTING = 3,
}
