export enum MatteMode {
  NORMAL,
  ALPHA,
  INVERTED_ALPHA,
  LUMA,
  INVERTED_LUMA,
}
