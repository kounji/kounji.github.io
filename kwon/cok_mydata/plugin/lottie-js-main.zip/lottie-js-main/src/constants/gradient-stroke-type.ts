export enum GradientStrokeType {
  LINEAR = 1,
  RADIAL = 2,
}
