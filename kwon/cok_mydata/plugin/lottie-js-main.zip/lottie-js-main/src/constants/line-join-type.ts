export enum LineJoinType {
  MITER = 1,
  ROUND = 2,
  BEVEL = 3,
}
