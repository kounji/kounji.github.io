export enum GradientFillType {
  NONE = 0,
  LINEAR = 1,
  RADIAL = 2,
  ANGULAR = 4,
  REFLECTED = 5,
  DIAMOND = 6,
}
