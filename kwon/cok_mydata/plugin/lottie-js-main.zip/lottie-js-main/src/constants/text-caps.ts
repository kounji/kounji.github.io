export enum TextCaps {
  REGULAR,
  ALL_CAPS,
  SMALL_CAPS,
}
