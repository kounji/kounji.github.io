---
'@lottiefiles/lottie-js': patch
---

**metadata**: set empty array for files with no keywords
