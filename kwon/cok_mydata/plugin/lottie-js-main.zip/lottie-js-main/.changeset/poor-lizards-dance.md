---
'@lottiefiles/lottie-js': patch
---

**metadata**: do not use the default generator when a file does not have metadata
