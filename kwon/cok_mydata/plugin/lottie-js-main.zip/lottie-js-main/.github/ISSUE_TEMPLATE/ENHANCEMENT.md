---
name: '📈 Enhancement'
about: Enhancement to our codebase that isn't a adding or changing a feature
---

## Overview

...

## Motivation

> What inspired this enhancement? What makes you think this should be included?

...

## Labels

- [ ] Add the `Type: Enhancement` label to this issue.
